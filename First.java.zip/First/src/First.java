//Name: Camron Campbell

public class First {

	public static void main(String[] args) {
		System.out.println("Hello World!");
		System.out.println("Job title: Software developer");
		System.out.println("Why: I enjoy programming and good money");
		System.out.println("Median Salary: 131,450");
	}
}
